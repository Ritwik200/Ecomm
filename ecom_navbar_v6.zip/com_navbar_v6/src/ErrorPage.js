import React from "react";

const ErrorPage = () => {
  return <div>ErrorPage</div>;
};

export default ErrorPage;
